# Email routing core logic - local development

Runs entirely on your Mac Mini. No database, no Graph API, no Azure.

    pip install duckdb fuzzywuzzy python-Levenshtein
    python3 validate.py

Expected output: `PASS - 29 rules loaded, 29 cases green`

## Files

| File | Role |
|---|---|
| `models.py` | dataclasses + normalization. Every char code is stripped and upper-cased once, here at the boundary. |
| `matcher.py` | operator dispatch and ALL/ANY evaluation. Pure functions, no I/O. |
| `repository.py` | one SQL text, two backends: `CsvRuleRepository` (DuckDB, local) and `PostgresRuleRepository` (psycopg2, container). |
| `validate.py` | runs `data/test_cases.csv` and prints one verdict. |
| `data/*.csv` | the three tables plus 29 test cases. |

## The swap to Postgres

`repository.py` holds the same SQL text for both backends. Only two things
differ: the connection, and `{p}` becoming `%s` instead of a literal. The table
names come from a dict, so `sot.` is already wired in.

    repo = PostgresRuleRepository(dsn, trail_id=2228, environment="PROD")

Everything above `build_rules()` is untouched by that change. That is the whole
point of the split: the part you cannot test locally is about twenty lines.

## What has been proven locally

Fault injection, not just a green run:

| Injected fault | Caught |
|---|---|
| D28 `enabled_flag` N→Y | yes - load count, TC007, TC009 |
| D25 conditions reactivated | yes - load count, TC027 negative case |
| D27 recipient reactivated | yes - TC024 recipient mismatch |
| All char columns padded to width 16 | still PASS - normalization holds |

That last row matters. Postgres pads `char(n)`, so `'FUZZY'` arrives as
`'FUZZY   '`. Padding every code column to width 16 and still passing means the
normalization boundary is doing its job, and this is no longer an unknown
waiting for the first container run.

## Adding test cases

Append a row to `data/test_cases.csv`. Pipe-separate multiple values, leave the
expected columns empty for a negative case. No code change.

## Still unproven until the container runs

- Is `fuzzywuzzy` in `requirements.txt`? Without it every FUZZY rule silently
  returns False. `validate.py` prints a warning if the import fails.
- Is `python-Levenshtein` installed? Without it fuzzywuzzy falls back to difflib
  and ratios shift slightly. Borderline cases could flip.
- Real `psycopg2` row shapes and the `sot.` grants.

## Known behaviour worth remembering

FUZZY at threshold 100 is not "exact". `token_set_ratio` returns 100 whenever
the stored value's tokens are a subset of the subject's, which is why TC013 and
TC015 match. For whole words FUZZY behaves like CONTAINS at any threshold. Use
EXACT when someone means exact.

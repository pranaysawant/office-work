# Email routing core logic - local development

Runs entirely on your Mac Mini. No database, no Graph API, no Azure.

    pip install duckdb fuzzywuzzy python-Levenshtein
    python3 validate.py

Expected output: `PASS - 29 rules loaded, 29 cases green`

## Files

| File | Role |
|---|---|
| `models.py` | dataclasses + normalization. Every char code is stripped and upper-cased once, here at the boundary. |
| `matcher.py` | operator dispatch and ALL/ANY evaluation. Pure functions, no I/O. |
| `repository.py` | one SQL text, two backends: `CsvRuleRepository` (DuckDB, local) and `PostgresRuleRepository` (psycopg2, container). |
| `validate.py` | runs `data/test_cases.csv` and prints one verdict. |
| `data/*.csv` | the three tables plus 29 test cases. |

## The swap to Postgres

`repository.py` holds the same SQL text for both backends. Only two things
differ: the connection, and `{p}` becoming `%s` instead of a literal. The table
names come from a dict, so `sot.` is already wired in.

    repo = PostgresRuleRepository(dsn, trail_id=2228, environment="PROD")

Everything above `build_rules()` is untouched by that change. That is the whole
point of the split: the part you cannot test locally is about twenty lines.

## What has been proven locally

Fault injection, not just a green run:

| Injected fault | Caught |
|---|---|
| D28 `enabled_flag` N→Y | yes - load count, TC007, TC009 |
| D25 conditions reactivated | yes - load count, TC027 negative case |
| D27 recipient reactivated | yes - TC024 recipient mismatch |
| All char columns padded to width 16 | still PASS - normalization holds |

That last row matters. Postgres pads `char(n)`, so `'FUZZY'` arrives as
`'FUZZY   '`. Padding every code column to width 16 and still passing means the
normalization boundary is doing its job, and this is no longer an unknown
waiting for the first container run.

## Adding test cases

Append a row to `data/test_cases.csv`. Pipe-separate multiple values, leave the
expected columns empty for a negative case. No code change.

## Still unproven until the container runs

- Is `fuzzywuzzy` in `requirements.txt`? Without it every FUZZY rule silently
  returns False. `validate.py` prints a warning if the import fails.
- Is `python-Levenshtein` installed? Without it fuzzywuzzy falls back to difflib
  and ratios shift slightly. Borderline cases could flip.
- Real `psycopg2` row shapes and the `sot.` grants.

## Known behaviour worth remembering

FUZZY at threshold 100 is not "exact". `token_set_ratio` returns 100 whenever
the stored value's tokens are a subset of the subject's, which is why TC013 and
TC015 match. For whole words FUZZY behaves like CONTAINS at any threshold. Use
EXACT when someone means exact.

## Serving all trails

All trails arrive in one landing mailbox, so rules are loaded and matched across
every trail at once.

    CsvRuleRepository(environment="PROD")                  # all trails
    CsvRuleRepository(environment="PROD", trail_id=2228)   # one trail

The rule queries JOIN `sot.trail`, so trail ids are never hard-coded and a rule
pointing at a trail that no longer exists is silently not served. Adding a trail
to `sot.trail` is enough for its rules to be picked up.

`build_rules()` logs a per-trail breakdown at load, e.g. `2228=29, 2822=2`.

### The risk this creates

Pooling means a rule owned by trail A can match an email belonging to trail B
and forward it to trail A's recipients. Neither rule has to be wrong - two
reasonable rules only have to overlap.

On the dummy data, 6 of 29 test subjects already collide, because trail 2822's
D33 says `CONTAINS 'File Accepted'` and trail 2228 has rules on the same phrase.
Real rules will collide more, since different trails handle similar document
types with similar subject vocabulary.

The team has told rule authors to be careful. That is a real control, but it is
a human one, so `collision_report.py` exists to make violations visible:

    python3 src/collision_report.py                # against the test cases
    python3 src/collision_report.py subjects.txt   # against real subject lines

Exit code 1 when any subject matches rules from more than one trail. Run it
whenever rules change. When a real corpus of subject lines is available, run it
against that - the test cases only prove the mechanism works.

### Recommended, not yet built

Log `trail_id` and matched `rule_id` on every forward. If a wrong-recipient
incident happens, that log is the difference between "we can show exactly which
rule did it" and a manual reconstruction. Cheap to add, only useful if it is
there beforehand.

# Dummy rule set — coverage map and expected results

Load file: `dummy_rules_postgres.sql`
Prefix: every rule id starts `DUMMY-`, every audit column is `DUMMY_PS`.

Row counts after load: **36 rules, 58 conditions, 42 recipients**.
A PROD run on trail 3610 should load **exactly 29 rules**.

---

## Rules that must NOT be picked up

| Rule | Why it must be skipped |
|---|---|
| DUMMY-3610-025 | every condition has `status_flag = 'I'` → rule has zero active conditions |
| DUMMY-3610-028 | `enabled_flag = 'N'`, status `'A'` |
| DUMMY-3610-029 | `enabled_flag = 'Y'`, status `'I'` |
| DUMMY-3610-030 | `enabled_flag = 'N'`, status `'I'` |
| DUMMY-3610-031 | `environment = 'NON-PROD'` |
| DUMMY-3611-032 | different trail |
| DUMMY-3611-033 | different trail |

D28–D31 all carry the same `CONTAINS 'TEST'` condition on purpose. Send a
subject of `TEST` and only D05 and D07 may fire. If any of D28–D31 appears, the
flag filtering is broken.

## Permutation coverage

| Dimension | Values exercised |
|---|---|
| Rule logic | ALL (D01,02,03,06,09,10,17,20,21,22,23,24,25,26,27,35,36) · ANY (D04,05,07,11,16,18,19,28–31,34) |
| Condition count | 1 · 2 · 3 · 5 (D20) · 6 (D19) |
| Operator | CONTAINS · ANY_OF · EXACT · STARTS_WITH · ENDS_WITH · FUZZY |
| Operators per rule | single-operator, two mixed (D10,D11,D16,D18), five (D20), all six (D19) |
| Threshold | 60 · 70 · 80 · 85 · 90 · 95 · 100 |
| Condition seq | contiguous 1,2,3 · gapped 10,20,30 (D03) · inserted out of order (D04) · 1–6 (D19) |
| Condition status | all A · one I (D24) · all I (D25) |
| Recipient count | 1 · 2 · 3 (D21) |
| Recipient type | USER · DISTRIBUTION_LIST |
| Recipient status | all A · one I (D26) · all I (D27) |
| enabled × status | Y/A · N/A · Y/I · N/I |
| Environment | PROD · NON-PROD |
| Trail | 3610 (34 rules) · 3611 (2 rules) |
| Dedupe | D02 and D22 share `dummy.shared@example.com` |
| Threshold precedence | D23 has condition threshold 40, rule threshold 90 |

---

## Expected results

Trail 3610, PROD. Rule column shows the last three digits.

| Test subject | Rules that should fire | Recipients |
|---|---|---|
| `File Accepted - 1272_3696_HSE_P` | 001,002,003,010,018,020,022,036 | 9 |
| `File Accepted - 1272_3696_EHS_P` | 001,009,018,036 | 4 |
| `RE: File Accepted - 1272_3696_HSE_P` | 001,002,003,008,018,022,036 | 8 |
| `Online Portal Hold And Release UPLOAD Notification` | 006 | 1 |
| `Online Portal Hold And Release UPLOAD Notification** - 1272_3696_HSE_P` | 018,022,035 | 4 |
| `TEST` | 005,007 | 2 |
| `PING` | 007 | 1 |
| `TESTING-EMAIL from vendor` | 004,005 | 2 |
| `DUMMY-EMAIL please ignore` | 004,005 | 2 |
| `ESDF submission pending` | 012,013,023 | 3 |
| `Shipment Manifest Confirmation for Order 88` | 014 | 1 |
| `Shipment Manifest` | 014 | 1 |
| `Quarterly Compliance Report` | 015 | 1 |
| `Quarterly Compliance Report v2` | 015 | 1 |
| `INVOICE 445 payment due` | 016,017 | 2 |
| `Invoice Reminder - 445` | 016,017 | 2 |
| `PAYROLL update for August` | 021 | 3 |
| `BENEFITS enrolment open` | 026 | 1 |
| `FW: ESCALATION - portal down` | 011,019 | 2 |
| `URGENT server down` | 024 | 1 |
| `SINGLE-ANY probe` | 034 | 1 |
| `file accepted - lowercase check` | 001,036 | 2 |
| `NOWHERE-TO-GO notice` | 027 | **0** — matches, forwards nothing |
| `Lunch tomorrow?` | none | 0 |

Two rows are the important ones. `NOWHERE-TO-GO notice` must match D27 and still
forward to nobody. `Lunch tomorrow?` must match nothing at all.

Recipient counts are after de-duplication. Row 1 hits eight rules whose recipient
lists total ten entries, but `dummy.shared@example.com` appears in both D02 and
D22, so nine unique addresses go out.

---

## Three things to decide before this becomes real

**1. `email_routing_rule_match_type` is now redundant.**
Every condition carries its own `email_routing_operator_code`. The rule-level
column duplicates it and the two can disagree. I populated it for compatibility,
but the engine should treat the condition-level code as authoritative and the
rule-level column as deprecated. Worth confirming with Ravi before build.

**2. FUZZY at threshold 95 or 100 does not mean "almost exact".**
`token_set_ratio` scores 100 whenever the stored value's tokens are a *subset* of
the subject's tokens. That is why `Shipment Manifest` alone matches D14 at
threshold 95, and `Quarterly Compliance Report v2` matches D15 at threshold 100.
For whole words, FUZZY behaves like CONTAINS no matter what threshold you set —
it only earns its keep on misspellings. If someone wants "exact", they need the
EXACT operator, not FUZZY at 100.

**3. Underscores are not token separators.**
fuzzywuzzy's preprocessor treats `_` as a word character, so `1272_3696_HSE_P`
stays one token. A FUZZY condition written as `1272 3696` scores 42 against it
and silently never fires. Any FUZZY rule aimed at your reference numbers must use
the exact underscore form. This is the most likely source of a "rule configured
but nothing happens" support ticket.

---

## Open question on rule id format

The UI screenshot shows Rule ID auto-generated as `TRAILID-001`, e.g. `3610-001`.
My ids are `DUMMY-3610-001` so cleanup can key off a prefix. If there is a CHECK
constraint or the UI reads these back and chokes on the format, switch to a
reserved serial band — `3610-901` through `3610-936` — and clean up on
`created_by = 'DUMMY_PS'` instead. Section 5 Option B already does that.

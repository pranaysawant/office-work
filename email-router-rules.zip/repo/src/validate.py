"""Validate the routing engine against data/test_cases.csv.

Run:  python3 validate.py
Exit code 0 means every case passed.

Add cases by appending rows to data/test_cases.csv. No code change needed.
"""

import csv
import logging
import sys
from pathlib import Path

from matcher import HAS_FUZZY, collect_recipients, find_matching_rules
from models import MatchContext
from repository import CsvRuleRepository

TRAIL_ID = 2228
ENVIRONMENT = "PROD"
EXPECTED_RULE_COUNT = 29
MUST_NOT_LOAD = ["DUMMY-2228-025", "DUMMY-2228-028", "DUMMY-2228-029",
                 "DUMMY-2228-030", "DUMMY-2228-031"]


def split(value):
    return [v for v in value.split("|") if v] if value else []


def main():
    logging.basicConfig(level=logging.ERROR, format="[%(levelname)s] %(message)s")
    failures = []

    if not HAS_FUZZY:
        print("WARNING: fuzzywuzzy not installed - every FUZZY rule will fail\n")

    rules = CsvRuleRepository(environment=ENVIRONMENT, trail_id=TRAIL_ID).load_rules()
    loaded = [r.rule_id for r in rules]

    # --- Layer 1: what loaded -------------------------------------------
    if len(rules) != EXPECTED_RULE_COUNT:
        failures.append(f"LOAD  expected {EXPECTED_RULE_COUNT} rules, got {len(rules)}")
    for rule_id in MUST_NOT_LOAD:
        if rule_id in loaded:
            failures.append(f"LOAD  {rule_id} was loaded but must be excluded")

    # --- Layer 2 and 3: matching and recipients -------------------------
    with open(Path(__file__).resolve().parent.parent / "data" / "test_cases.csv") as f:
        cases = list(csv.DictReader(f))

    for case in cases:
        ctx = MatchContext(subject=case["subject"])
        matched = find_matching_rules(rules, ctx)
        got_rules = [r.rule_id for r in matched]
        got_recipients = collect_recipients(matched)

        want_rules = split(case["expected_rule_ids"])
        want_recipients = split(case["expected_recipients"])

        if got_rules != want_rules:
            failures.append(
                f"{case['case_id']} RULES   {case['subject']!r}\n"
                f"          want {want_rules or 'none'}\n"
                f"          got  {got_rules or 'none'}")
        if got_recipients != want_recipients:
            failures.append(
                f"{case['case_id']} RCPT    {case['subject']!r}\n"
                f"          want {want_recipients or 'none'}\n"
                f"          got  {got_recipients or 'none'}")

        if case["kind"] == "NEG" and got_rules:
            failures.append(
                f"{case['case_id']} NEGATIVE case matched {got_rules}")

    # --- Verdict ---------------------------------------------------------
    print("=" * 62)
    if failures:
        print(f"FAIL - {len(failures)} problem(s)")
        print("=" * 62)
        for f in failures:
            print(f)
    else:
        print(f"PASS - {len(rules)} rules loaded, {len(cases)} cases green")
    print("=" * 62)

    # Always dump what loaded, so a failing run is diagnosable without a rerun.
    print("\nLOADED RULES")
    for r in rules:
        conds = "; ".join(f"{c.seq}:{c.operator_code}:{c.value}" for c in r.conditions)
        print(f"  {r.rule_id}  {r.logic:3} thr={r.fuzzy_threshold:3} "
              f"rcpt={len(r.recipients)}  [{conds}]")

    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())

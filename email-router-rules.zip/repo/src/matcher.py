"""Match an inbound email against loaded rules.

All string comparison is case-insensitive, matching the behaviour of the
existing JSON-based router.
"""

import logging
from typing import List

from models import Condition, EmailRule, MatchContext

logger = logging.getLogger(__name__)

try:
    from fuzzywuzzy import fuzz

    HAS_FUZZY = True
except ImportError:  # pragma: no cover
    HAS_FUZZY = False


def _contains(haystack: str, needle: str, threshold: int) -> bool:
    return needle.lower() in haystack.lower()


def _exact(haystack: str, needle: str, threshold: int) -> bool:
    return haystack.lower() == needle.lower()


def _starts_with(haystack: str, needle: str, threshold: int) -> bool:
    return haystack.lower().startswith(needle.lower())


def _ends_with(haystack: str, needle: str, threshold: int) -> bool:
    return haystack.lower().endswith(needle.lower())


def _fuzzy(haystack: str, needle: str, threshold: int) -> bool:
    if not HAS_FUZZY:
        logger.warning("FUZZY operator requested but fuzzywuzzy is not installed")
        return False
    return fuzz.token_set_ratio(haystack.lower(), needle.lower()) >= threshold


# ANY_OF reuses CONTAINS per split value; the OR is applied in evaluate_condition.
OPERATORS = {
    "CONTAINS": _contains,
    "ANY_OF": _contains,
    "EXACT": _exact,
    "STARTS_WITH": _starts_with,
    "ENDS_WITH": _ends_with,
    "FUZZY": _fuzzy,
}


def evaluate_condition(condition: Condition, ctx: MatchContext, threshold: int) -> bool:
    """True if this single condition holds. Fails closed on any error."""
    operator = OPERATORS.get(condition.operator_code)
    if operator is None:
        logger.error(
            "Condition %s uses unknown operator %r - treating as no match",
            condition.condition_id,
            condition.operator_code,
        )
        return False

    try:
        subject_value = ctx.value_for(condition.field_code)
    except KeyError:
        logger.error(
            "Condition %s uses unknown field %r - treating as no match",
            condition.condition_id,
            condition.field_code,
        )
        return False

    return any(operator(subject_value, v, threshold) for v in condition.values())


def rule_matches(rule: EmailRule, ctx: MatchContext) -> bool:
    """Apply rule-level ALL/ANY logic across the rule's active conditions."""
    if not rule.conditions:
        # Should not happen: conditionless rules are dropped at load time.
        logger.error("Rule %s reached matching with zero conditions", rule.rule_id)
        return False

    results = (
        evaluate_condition(c, ctx, rule.fuzzy_threshold) for c in rule.conditions
    )
    return all(results) if rule.logic == "ALL" else any(results)


def find_matching_rules(rules: List[EmailRule], ctx: MatchContext) -> List[EmailRule]:
    matched = [r for r in rules if rule_matches(r, ctx)]
    if not matched:
        logger.info("Subject %r did not match any rule", ctx.subject)
    return matched


def collect_recipients(matched: List[EmailRule]) -> List[str]:
    """Unique recipient emails, in (rule order, recipient seq) order."""
    ordered = []
    for rule in matched:
        for recipient in rule.recipients:
            ordered.append(recipient.email)
    return list(dict.fromkeys(ordered))

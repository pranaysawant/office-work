"""Domain model for database-driven email routing rules.

Shape mirrors the three Postgres tables:
    email_routing_rule -> EmailRule
    email_routing_condition -> Condition
    email_routing_recipient -> Recipient

Normalization rule: every code/flag coming out of a `char` column is stripped
and upper-cased exactly once, here at the boundary. Nothing downstream calls
.strip() again.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

VALID_FIELD_CODES = {"SUBJECT", "SENDER", "TO", "BODY", "HAS_ATTACHMENT"}
VALID_OPERATOR_CODES = {"CONTAINS", "ANY_OF", "EXACT", "STARTS_WITH", "ENDS_WITH", "FUZZY"}
VALID_LOGIC = {"ALL", "ANY"}

ANY_OF_DELIMITER = "|"
DEFAULT_FUZZY_THRESHOLD = 80


def code(value: Any) -> str:
    """Normalize a char-column code: strip padding, upper-case."""
    if value is None:
        return ""
    return str(value).strip().upper()


def text(value: Any) -> str:
    """Normalize a free-text column: strip surrounding whitespace only."""
    if value is None:
        return ""
    return str(value).strip()


def is_active(flag: Any) -> bool:
    """A status flag is active only when it is exactly 'A'."""
    return code(flag) == "A"


def is_enabled(flag: Any) -> bool:
    """An enabled flag is enabled only when it is exactly 'Y'."""
    return code(flag) == "Y"


@dataclass(frozen=True)
class MatchContext:
    """Everything about an inbound email that a condition may inspect."""

    subject: str = ""
    sender: str = ""
    to: str = ""
    body: str = ""
    has_attachment: bool = False

    def value_for(self, field_code: str) -> str:
        if field_code == "SUBJECT":
            return self.subject
        if field_code == "SENDER":
            return self.sender
        if field_code == "TO":
            return self.to
        if field_code == "BODY":
            return self.body
        if field_code == "HAS_ATTACHMENT":
            return "Y" if self.has_attachment else "N"
        raise KeyError(field_code)


@dataclass(frozen=True)
class Condition:
    condition_id: Any
    seq: int
    field_code: str
    operator_code: str
    value: str

    def values(self) -> List[str]:
        """Split the value for ANY_OF; single-element list otherwise."""
        if self.operator_code == "ANY_OF":
            return [v.strip() for v in self.value.split(ANY_OF_DELIMITER) if v.strip()]
        return [self.value]


@dataclass(frozen=True)
class Recipient:
    seq: int
    email: str
    type_code: str


@dataclass
class EmailRule:
    rule_id: str
    name: str
    description: str
    trail_id: Optional[int]
    environment: str
    logic: str
    fuzzy_threshold: int
    conditions: List[Condition] = field(default_factory=list)
    recipients: List[Recipient] = field(default_factory=list)

    @property
    def recipient_emails(self) -> List[str]:
        return [r.email for r in self.recipients]

    def __repr__(self) -> str:
        return (
            f"EmailRule(id={self.rule_id}, name={self.name!r}, logic={self.logic}, "
            f"conditions={len(self.conditions)}, recipients={len(self.recipients)})"
        )


def summarize(rules: List[EmailRule]) -> Dict[str, Any]:
    """Startup-log friendly summary of what actually loaded."""
    return {
        "total_rules": len(rules),
        "rules": [
            {
                "id": r.rule_id,
                "name": r.name,
                "logic": r.logic,
                "threshold": r.fuzzy_threshold,
                "conditions": [
                    f"{c.field_code}/{c.operator_code}/{c.value}" for c in r.conditions
                ],
                "recipient_count": len(r.recipients),
            }
            for r in rules
        ],
    }

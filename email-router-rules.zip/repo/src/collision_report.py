"""Cross-trail collision report.

All trails share one landing mailbox, so matching runs across every trail's
rules at once. That means a rule owned by trail A can match an email that
belongs to trail B and forward it to trail A's recipients. Nobody has to write
a bad rule for this to happen - two reasonable rules in different trails only
have to overlap.

This script finds those overlaps BEFORE anything is forwarded. Run it whenever
rules change, and on a corpus of real subject lines when you have one.

    python3 src/collision_report.py                  # uses data/test_cases.csv
    python3 src/collision_report.py subjects.txt     # one subject per line

Exit code 1 if any subject matches rules from more than one trail.
"""

import csv
import logging
import sys
from pathlib import Path

from matcher import find_matching_rules
from models import MatchContext
from repository import DATA_DIR, CsvRuleRepository

ENVIRONMENT = "PROD"


def load_subjects(argv):
    if len(argv) > 1:
        path = Path(argv[1])
        return [line.strip() for line in path.read_text().splitlines() if line.strip()]
    with open(DATA_DIR / "test_cases.csv") as f:
        return [row["subject"] for row in csv.DictReader(f)]


def main():
    logging.basicConfig(level=logging.ERROR)

    rules = CsvRuleRepository(environment=ENVIRONMENT).load_rules()
    trail_of = {r.rule_id: r.trail_id for r in rules}
    trails = sorted({r.trail_id for r in rules})
    subjects = load_subjects(sys.argv)

    print(f"{len(rules)} rules across {len(trails)} trail(s): {trails}")
    print(f"Checking {len(subjects)} subject(s)\n")

    collisions = []
    for subject in subjects:
        matched = find_matching_rules(rules, MatchContext(subject=subject))
        by_trail = {}
        for rule in matched:
            by_trail.setdefault(trail_of[rule.rule_id], []).append(rule)
        if len(by_trail) > 1:
            collisions.append((subject, by_trail))

    if not collisions:
        print("No cross-trail collisions found.")
        return 0

    print("=" * 72)
    print(f"CROSS-TRAIL COLLISIONS: {len(collisions)} of {len(subjects)} subjects")
    print("=" * 72)
    for subject, by_trail in collisions:
        print(f"\n  {subject}")
        for trail_id in sorted(by_trail):
            for rule in by_trail[trail_id]:
                print(f"    trail {trail_id}  {rule.rule_id}  {rule.name}")
                print(f"      -> {', '.join(rule.recipient_emails) or 'no recipients'}")
    print("\nEach subject above would be forwarded to recipients in every trail")
    print("listed. Confirm that is intended before these rules go live.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

"""Load routing rules.

One assembly path, two backends:
    CsvRuleRepository      - local, DuckDB over the fixture CSVs
    PostgresRuleRepository - container, psycopg2 over sot.*

The SQL text is identical for both. Only the connection and the parameter
placeholder differ, so what you validate locally is what runs in Azure.

Flag policy:
    rule loads only if enabled_flag='Y' AND status_flag='A'
    conditions and recipients load only if their own status_flag='A'
    a rule left with zero active conditions is dropped (fail closed)
    rule-level fuzzy_threshold is the only threshold; the condition-level
      threshold column is read and ignored
"""

import logging
from pathlib import Path
from typing import Any, Dict, List

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

from models import (
    DEFAULT_FUZZY_THRESHOLD,
    VALID_FIELD_CODES,
    VALID_LOGIC,
    VALID_OPERATOR_CODES,
    Condition,
    EmailRule,
    Recipient,
    code,
    is_active,
    is_enabled,
    text,
)

logger = logging.getLogger(__name__)

# {rule}, {cond}, {rcpt}, {trail} become schema-qualified table names in
# Postgres and quoted CSV paths in DuckDB. {p} is the parameter placeholder.
# {where} is either empty (serve every trail in the trail table) or a filter
# down to one trail. Joining to the trail table means a rule pointing at a
# trail that no longer exists is never served.
RULE_SQL = """
    SELECT r.email_routing_rule_id, r.email_routing_rule_name,
           r.email_routing_rule_description, r.trail_id,
           r.email_routing_rule_environment, r.email_routing_rule_logic,
           r.email_routing_rule_fuzzy_threshold, r.email_routing_rule_enabled_flag,
           r.email_routing_rule_status_flag
      FROM {rule} r
      JOIN {trail} t ON t.trail_id = r.trail_id
     {where}
"""

CONDITION_SQL = """
    SELECT c.email_routing_condition_id, c.email_routing_rule_id,
           c.email_routing_condition_seq, c.email_routing_field_code,
           c.email_routing_operator_code, c.email_routing_condition_value,
           c.email_routing_condition_status_flag
      FROM {cond} c
      JOIN {rule} r ON r.email_routing_rule_id = c.email_routing_rule_id
      JOIN {trail} t ON t.trail_id = r.trail_id
     {where}
     ORDER BY c.email_routing_rule_id, c.email_routing_condition_seq
"""

RECIPIENT_SQL = """
    SELECT p.email_routing_rule_id, p.email_routing_recipient_seq,
           p.email_routing_recipient_email, p.email_routing_recipient_type_code,
           p.email_routing_recipient_status_flag
      FROM {rcpt} p
      JOIN {rule} r ON r.email_routing_rule_id = p.email_routing_rule_id
      JOIN {trail} t ON t.trail_id = r.trail_id
     {where}
     ORDER BY p.email_routing_rule_id, p.email_routing_recipient_seq
"""


def _int_or(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def build_rules(rule_rows, condition_rows, recipient_rows, environment):
    """Assemble validated EmailRule objects from raw table rows."""
    wanted_env = code(environment)

    conditions: Dict[str, List] = {}
    broken: set = set()
    for row in condition_rows:
        if not is_active(row["email_routing_condition_status_flag"]):
            continue
        rule_id = text(row["email_routing_rule_id"])
        field_code = code(row["email_routing_field_code"])
        operator_code = code(row["email_routing_operator_code"])

        if field_code not in VALID_FIELD_CODES:
            logger.error("Rule %s condition %s: unknown field code %r",
                         rule_id, row["email_routing_condition_id"], field_code)
            broken.add(rule_id)
            continue
        if operator_code not in VALID_OPERATOR_CODES:
            logger.error("Rule %s condition %s: unknown operator code %r",
                         rule_id, row["email_routing_condition_id"], operator_code)
            broken.add(rule_id)
            continue

        conditions.setdefault(rule_id, []).append(
            Condition(
                condition_id=row["email_routing_condition_id"],
                seq=_int_or(row["email_routing_condition_seq"], 0),
                field_code=field_code,
                operator_code=operator_code,
                value=text(row["email_routing_condition_value"]),
            )
        )

    recipients: Dict[str, List] = {}
    for row in recipient_rows:
        if not is_active(row["email_routing_recipient_status_flag"]):
            continue
        email = text(row["email_routing_recipient_email"])
        if not email:
            continue
        recipients.setdefault(text(row["email_routing_rule_id"]), []).append(
            Recipient(
                seq=_int_or(row["email_routing_recipient_seq"], 0),
                email=email,
                type_code=code(row["email_routing_recipient_type_code"]),
            )
        )

    rules: List[EmailRule] = []
    for row in rule_rows:
        rule_id = text(row["email_routing_rule_id"])

        if not is_enabled(row["email_routing_rule_enabled_flag"]):
            continue
        if not is_active(row["email_routing_rule_status_flag"]):
            continue
        if code(row["email_routing_rule_environment"]) != wanted_env:
            continue

        logic = code(row["email_routing_rule_logic"])
        if logic not in VALID_LOGIC:
            logger.error("Rule %s: invalid logic %r - dropping rule", rule_id, logic)
            continue
        if rule_id in broken:
            logger.error("Rule %s: has an invalid condition - dropping rule", rule_id)
            continue

        rule_conditions = conditions.get(rule_id, [])
        if not rule_conditions:
            logger.error("Rule %s: no active conditions - dropping rule (fail closed)",
                         rule_id)
            continue

        rule_recipients = recipients.get(rule_id, [])
        if not rule_recipients:
            logger.warning("Rule %s: no active recipients - will match but forward "
                           "nothing", rule_id)

        rules.append(EmailRule(
            rule_id=rule_id,
            name=text(row["email_routing_rule_name"]),
            description=text(row["email_routing_rule_description"]),
            trail_id=row["trail_id"],
            environment=code(row["email_routing_rule_environment"]),
            logic=logic,
            fuzzy_threshold=_int_or(row["email_routing_rule_fuzzy_threshold"],
                                    DEFAULT_FUZZY_THRESHOLD),
            conditions=rule_conditions,
            recipients=rule_recipients,
        ))

    rules.sort(key=lambda r: (r.trail_id, r.rule_id))
    per_trail = {}
    for r in rules:
        per_trail[r.trail_id] = per_trail.get(r.trail_id, 0) + 1
    logger.info("Loaded %d rules across %d trail(s) in %s: %s",
                len(rules), len(per_trail), wanted_env,
                ", ".join(f"{t}={n}" for t, n in sorted(per_trail.items())))
    return rules


class CsvRuleRepository:
    """Local backend. DuckDB reads the fixture CSVs as tables."""

    def __init__(self, environment: str, trail_id=None, data_dir=None):
        self.trail_id = trail_id
        self.environment = environment
        data_dir = Path(data_dir) if data_dir else DATA_DIR
        self.tables = {
            "rule": f"'{data_dir}/email_routing_rule.csv'",
            "cond": f"'{data_dir}/email_routing_condition.csv'",
            "rcpt": f"'{data_dir}/email_routing_recipient.csv'",
            "trail": f"'{data_dir}/trail.csv'",
        }

    def _rows(self, sql: str) -> List[Dict[str, Any]]:
        import duckdb

        where = "" if self.trail_id is None else f"WHERE r.trail_id = {self.trail_id}"
        query = sql.format(p="?", where=where, **self.tables)
        result = duckdb.sql(query)
        cols = result.columns
        return [dict(zip(cols, row)) for row in result.fetchall()]

    def load_rules(self) -> List[EmailRule]:
        return build_rules(
            self._rows(RULE_SQL),
            self._rows(CONDITION_SQL),
            self._rows(RECIPIENT_SQL),
            self.environment,
        )


class PostgresRuleRepository:
    """Container backend. Same SQL, real tables."""

    def __init__(self, dsn: str, environment: str, trail_id=None,
                 schema: str = "sot"):
        self.dsn = dsn
        self.trail_id = trail_id
        self.environment = environment
        self.tables = {
            "rule": f"{schema}.email_routing_rule",
            "cond": f"{schema}.email_routing_condition",
            "rcpt": f"{schema}.email_routing_recipient",
            "trail": f"{schema}.trail",
        }

    def _rows(self, sql: str) -> List[Dict[str, Any]]:
        import psycopg2
        import psycopg2.extras

        where = "" if self.trail_id is None else "WHERE r.trail_id = %s"
        query = sql.format(p="%s", where=where, **self.tables)
        params = (self.trail_id,) if self.trail_id is not None else ()
        with psycopg2.connect(self.dsn) as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query, params)
                return [dict(r) for r in cur.fetchall()]

    def load_rules(self) -> List[EmailRule]:
        return build_rules(
            self._rows(RULE_SQL),
            self._rows(CONDITION_SQL),
            self._rows(RECIPIENT_SQL),
            self.environment,
        )

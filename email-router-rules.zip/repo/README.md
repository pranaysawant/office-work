# Email Routing Service - DB-driven rules

Core matching logic for the intelligent email routing service, developed and
validated locally with no database or Azure access required.

## Quick start

    pip install -r requirements.txt
    python3 src/validate.py

Expected: `PASS - 29 rules loaded, 29 cases green`

## Layout

    sql/dummy_rules_postgres.sql   36 dummy rules for sot.* (load + cleanup + verify)
    src/models.py                  dataclasses, normalization boundary
    src/matcher.py                 operator dispatch, ALL/ANY evaluation
    src/repository.py              one SQL text, DuckDB + Postgres backends
    src/validate.py                test runner, prints one verdict
    data/*.csv                     the three tables as fixtures + 29 test cases
    docs/EXPECTED_RESULTS.md       coverage map and expected match results
    docs/CORE_LOGIC.md             design notes and what is proven vs unproven

## Status

Validated locally against the CSV fixtures, including fault injection and
simulated Postgres char(n) padding. The Postgres backend is written but not yet
exercised against the real database.

Trail ids: 2228 (34 rules) and 2822 (2 rules). Schema: `sot`.
